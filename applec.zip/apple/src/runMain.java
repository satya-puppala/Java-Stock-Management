
public class runMain 
{
    public static void main(String[] args)
    {
                
             new add();  
    } 
}
