import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class login extends JFrame implements ActionListener
{
    //panels
    JPanel blue = new JPanel();
    JPanel white = new JPanel();
    JPanel bluein1 = new JPanel();
    JPanel bluein2 = new JPanel();
    JPanel grid = new JPanel();
    JPanel drop = new JPanel();
    JPanel pak = new JPanel();
    
    // label,textfeilds,buttons   
    JLabel main = new JLabel();
    JLabel userid = new JLabel(" ",SwingConstants.CENTER);
    JLabel passwrd = new JLabel(" ",SwingConstants.CENTER);
    JTextField id = new JTextField();
    JPasswordField pass = new JPasswordField();
    JButton log = new JButton();
    
    public login()
    {
        setTitle("u1726436");
        setSize(747,600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        
        //main layout
        add(BorderLayout.NORTH,blue);
        blue.setBackground(new java.awt.Color(102,204,255));
        blue.setPreferredSize(new Dimension(747,245));
        add(BorderLayout.SOUTH,white);
        white.setBackground(new java.awt.Color(255,255,255));
        white.setPreferredSize(new Dimension(747,355));

       
        
        //setting panels for main label
        
        blue.add(BorderLayout.NORTH,bluein1);
        bluein1.setPreferredSize(new Dimension(747,125));
        bluein1.setBackground(new java.awt.Color(102,204,255));
        blue.add(BorderLayout.SOUTH,bluein2);
        bluein2.setPreferredSize(new Dimension(600,120));
        bluein2.setBackground(new java.awt.Color(102,204,255));
        bluein2.setLayout(new FlowLayout(FlowLayout.LEFT));
        bluein2.add(main);
        pak.add(userid);
            pak.add(id);
            pak.add(passwrd);
            pak.add(pass);
            pak.add(log);
        
         //main label
            main.setText("Apple Store");
            main.setFont(new java.awt.Font("Gill Sans Nova", 2, 36));
            main.setForeground(Color.white);
            main.setIcon(new javax.swing.ImageIcon("C:\\Users\\satya\\Downloads\\icons8-apple-50.png"));
        
      
             //panels for textfields
            
            white.add(BorderLayout.NORTH,grid);
            grid.setPreferredSize(new Dimension(747,51));
            grid.setBackground(new java.awt.Color(255,255,255));
            white.add(BorderLayout.CENTER,pak);
            pak.setPreferredSize(new Dimension(250,250));
            pak.setBackground(new java.awt.Color(255,255,255));        
            white.add(BorderLayout.SOUTH,drop);
            drop.setPreferredSize(new Dimension(747,54));
            drop.setBackground(new java.awt.Color(255,255,255)); 
            pak.setLayout(new GridLayout(0,1,5,5));
            
            
           
            
       // components
       
        
        id.setPreferredSize(new Dimension(200,25));
        id.setBackground(Color.WHITE);
        id.setForeground(Color.black);
        pass.setPreferredSize(new Dimension(200,25));
        pass.setBackground(Color.WHITE);
        pass.setForeground(Color.black);
        
        passwrd.setFont(new java.awt.Font("Gill Sans MT", 0, 18));
        passwrd.setForeground(new java.awt.Color(93, 188, 210));
        passwrd.setIcon(new javax.swing.ImageIcon("C:\\Users\\satya\\Downloads\\icons8-lock-48.png")); 
        passwrd.setText("Password");
            
            
        userid.setFont(new java.awt.Font("Gill Sans MT", 0, 18));
        userid.setForeground(new java.awt.Color(93, 188, 210));
        userid.setIcon(new javax.swing.ImageIcon("C:\\Users\\satya\\Downloads\\icons8-customer-48.png")); 
        userid.setText(" Username");
            
            
                      
            log.setBackground(new java.awt.Color(93, 188, 210));
            log.setForeground(new java.awt.Color(255, 255, 255));
            log.setText("    Login    ");
            log.setPreferredSize(new Dimension(4,40));
            log.setBorder(new javax.swing.border.MatteBorder(2, 2, 2, 2, new java.awt.Color(10,20,255)));
            log.addActionListener(this);
        
            
        
               
       
  
    }
    
    public void actionPerformed(ActionEvent e)
    {
        try{
         if(id.getText().equals("apple") && pass.getText().equals("1001"))
            {
                new mainscreen();
                this.dispose();
            }
            else
            {
                 JOptionPane.showMessageDialog(null,"please enter correct details");
                 id.setText("");
                 pass.setText("");
            }
        }catch(Exception y){
            
        }
        
        
    }
    
}

