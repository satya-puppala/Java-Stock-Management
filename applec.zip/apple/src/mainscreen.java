import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class mainscreen extends JFrame implements ActionListener
{
    //panels
    JPanel blue = new JPanel();
    JPanel white = new JPanel();
    JPanel bluein1 = new JPanel();
    JPanel bluein2 = new JPanel();
    JPanel grid = new JPanel();
    JPanel drop = new JPanel();
    JPanel pak = new JPanel();
    JPanel mid = new JPanel();
    
     // label  
        JLabel main = new JLabel();
   
     //buttons
        
        JButton ADD = new JButton();
        JButton EDIT = new JButton();
        JButton SELL = new JButton();
        
        
    
    public mainscreen()
    {
        
        setTitle("u1726436");
        setSize(632,600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        
        //main layout
        add(BorderLayout.NORTH,blue);
        blue.setBackground(new java.awt.Color(39,118,239));
        blue.setPreferredSize(new Dimension(632,181));
        add(BorderLayout.SOUTH,white);
        white.setBackground(new java.awt.Color(255,255,255));
        white.setPreferredSize(new Dimension(632,419));
        
        //layouts
        blue.add(BorderLayout.NORTH,bluein1);
        bluein1.setPreferredSize(new Dimension(632,81));
        bluein1.setBackground(new java.awt.Color(39,118,239));
        blue.add(BorderLayout.SOUTH,bluein2);
        bluein2.setPreferredSize(new Dimension(500,100));
        bluein2.setBackground(new java.awt.Color(39,118,239));
        bluein2.setLayout(new FlowLayout(FlowLayout.LEFT));
        bluein2.add(main);
        
        //main label
            main.setText("Apple");
            main.setFont(new java.awt.Font("Gill Sans Nova", 2, 36));
            main.setForeground(Color.white);
            main.setIcon(new javax.swing.ImageIcon("C:\\Users\\satya\\Downloads\\icons8-apple-50.png"));
            
            //panels
            white.add(BorderLayout.NORTH,grid);
            grid.setPreferredSize(new Dimension(632,130));
            grid.setBackground(new java.awt.Color(255,255,255));
            white.add(BorderLayout.CENTER,pak);
            pak.setPreferredSize(new Dimension(370,57));
            pak.setBackground(new java.awt.Color(255,255,255));
            pak.setLayout(new GridLayout(0,2,115,50));
            white.add(BorderLayout.SOUTH,drop);
            drop.setPreferredSize(new Dimension(632,169));
            drop.setBackground(new java.awt.Color(255,255,255));
            drop.add(BorderLayout.CENTER,mid);
            mid.setPreferredSize(new Dimension(260,57)); 
            mid.setLayout(new GridLayout(0,2,0,57));
            mid.setBackground(Color.white);
            pak.add(ADD);
            pak.add(EDIT);
            mid.add(SELL);
                                                                                            
            //buttons
            ADD.setPreferredSize(new Dimension(115,57));
            ADD.setBackground(new java.awt.Color(255, 255, 255));
            ADD.setFont(new java.awt.Font("Arial", 3, 14)); // NOI18N
            ADD.setForeground(new java.awt.Color(39, 118, 239));
            ADD.setIcon(new javax.swing.ImageIcon("C:\\Users\\satya\\Contacts\\Desktop\\698913-icon-81-document-add-128.png")); // NOI18N
            ADD.setText("ADD");
            EDIT.setPreferredSize(new Dimension(115,57));
            EDIT.setFont(new java.awt.Font("Arial", 3, 14)); 
            EDIT.setText("EDIT");
            EDIT.setBackground(Color.white);
            EDIT.setForeground(new java.awt.Color(39, 118, 239));
            EDIT.setIcon(new javax.swing.ImageIcon("C:\\Users\\satya\\Contacts\\Desktop\\edit.png"));
            SELL.setPreferredSize(new Dimension(115,57));
            SELL.setBackground(new java.awt.Color(255, 255, 255));
            SELL.setFont(new java.awt.Font("Arial", 3, 14)); 
            SELL.setForeground(new java.awt.Color(39, 118, 239));
            SELL.setIcon(new javax.swing.ImageIcon("C:\\Users\\satya\\Downloads\\icons8-buy-48.png")); 
            SELL.setText("SELL");
            
            //actionlistener
            
            ADD.addActionListener(this);
            SELL.addActionListener(this);
            EDIT.addActionListener(this);
            
            
            
    }
    public void actionPerformed(ActionEvent g)
    {
        try{
        if(g.getSource() == ADD)
        {
            new add();
            this.dispose();
        }
        if(g.getSource() == EDIT)
        {
            new edit();
            this.dispose();
        }
        if(g.getSource() == SELL)
                {
                    new sell();
                    this.dispose();
                }
        }catch(Exception z)
        {
            
        }
        
    }
}
