import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class add extends JFrame implements ActionListener {
    //panels
    JPanel blue = new JPanel();
    JPanel white = new JPanel();
    JPanel bluein1 = new JPanel();
    JPanel bluein2 = new JPanel();
    JPanel grid = new JPanel();
    JPanel drop = new JPanel();
    JPanel pak = new JPanel();
    
    //labels 
    JLabel main = new JLabel();
    
    //buttons
    JButton back = new JButton();
    JButton ADD = new JButton();
    
    public add()
    {
        setTitle("u1726436");
        setSize(632,600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        
        add(BorderLayout.NORTH,blue);
        blue.setBackground(new java.awt.Color(1, 31, 75));
        blue.setPreferredSize(new Dimension(632,181));
        add(BorderLayout.SOUTH,white);
        white.setBackground(new java.awt.Color(255,255,255));
        white.setPreferredSize(new Dimension(632,419));
        
        //layouts
        blue.add(BorderLayout.NORTH,bluein1);
        bluein1.setPreferredSize(new Dimension(532,81));
        bluein1.setBackground(new java.awt.Color(1, 31, 75));
        bluein1.setLayout(new FlowLayout(FlowLayout.LEFT));
        blue.add(BorderLayout.SOUTH,bluein2);
        bluein2.setPreferredSize(new Dimension(500,100));
        bluein2.setBackground(new java.awt.Color(1, 31, 75));
        bluein2.setLayout(new FlowLayout(FlowLayout.LEFT));
        bluein2.add(main);
        bluein1.add(ADD);
        
        
        ADD.setBackground(new java.awt.Color(1, 31, 75));
        ADD.setBorder(null);
        ADD.setIcon(new javax.swing.ImageIcon("C:\\Users\\satya\\Downloads\\icons8-undo-26.png"));
        
        main.setFont(new java.awt.Font("Gill Sans Nova", 2, 36)); // NOI18N
        main.setForeground(new java.awt.Color(255, 255, 255));
        main.setIcon(new javax.swing.ImageIcon("C:\\Users\\satya\\Downloads\\icons8-plus-math-48.png")); // NOI18N
        main.setText("Add New Product");  
        
    }
    public void actionPerformed(ActionEvent k)
    {
        
    }
}
